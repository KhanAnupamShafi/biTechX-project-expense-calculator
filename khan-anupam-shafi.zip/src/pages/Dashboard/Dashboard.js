import React from "react";

const Dashboard = () => {
  return (
    <div>
      <div class="flex-1 p-10 text-2xl font-bold">content goes here</div>
      <div class=" p-10 text-2xl font-bold">
        <h1>this is dashboard</h1>
      </div>
    </div>
  );
};

export default Dashboard;
