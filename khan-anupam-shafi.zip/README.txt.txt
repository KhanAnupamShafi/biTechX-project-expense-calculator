Installation Process:

step 1: unzip all files in a folder
step 2:  inside the folder run the command->   'npm start'